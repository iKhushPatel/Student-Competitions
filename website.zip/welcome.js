var myWindow;

function selectCity
{
	myWindow = window.open("", "myWindow", "width=200, height=100");
}

function leave
{
	myWindow.close();
}


function varun()
{
	alert("Hello Esada");
	
}